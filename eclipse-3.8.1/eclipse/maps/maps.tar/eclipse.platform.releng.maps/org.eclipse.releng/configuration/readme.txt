This folder is to hold files or properties that are used by our one, 
common eclipsebuilder, org.eclipse.releng.eclipsebuilder. 
This allows the one common eclispebuilder 
to stay constant for different streams or releases 
and anything that is "branch sensitive" can be 
defined or controled from files or properties in this folder. 

There there are two main parts, 

eclipseBuilderOverlays. 

These files literally overlay (replace) files in 
org.eclipse.releng.eclipsebuilder so has to mimic that directory structure.
It would normally only contain "replacements" for things in the "buildConfigs"
portion of org.eclipse.releng.eclipsebuilder. (not "how to do things" scripts, 
since that should be possible to do with normal ant and/or a few properties). 

The strategy or plan will be that this folder will be
empty for the most forward stream. That is, org.eclipse.releng.eclipsebuilder
will be kept accurate for the most forward stream, and only deviations "for old
things" be maintain here in maintenance branches. 

streamSpecific-build.properties

This file contains ant properties that in one way or another control 
what the eclipse builder does. Sometime these properties will vary only be 
value from one stream to antoher, but here it would be not be uncommon 
to have variables that are required by most forward stream, 
but not necessarily required by maintenance branches (or, "old things"). 

Issues and transition initially documented in bug 376217. 
https://bugs.eclipse.org/bugs/show_bug.cgi?id=376217 

